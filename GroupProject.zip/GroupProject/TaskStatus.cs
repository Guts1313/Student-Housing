﻿using System;

namespace TestingUsers
{
    [Serializable]
    public enum TaskStatus
    {
        Assigned = 1,
        Accepted = 2,
        Declined = 3,
        Completed = 4
        
    }
}