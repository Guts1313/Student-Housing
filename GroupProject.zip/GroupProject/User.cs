﻿using System;
using System.Collections.Generic;

namespace TestingUsers
{
    [Serializable]
    public class User
    {
        private string name;
        private int age;
        private int id;
        public List<Task> AssignedTasks { get; }
        public int Id => id;
        
        
        public User(string name, int age, int id)
        {
            this.name = name;
            this.age = age;
            this.id = id;
            AssignedTasks = new List<Task>();
        }

        public void GetTask(Task task)
        {
            task.ChangeTaskStatus(TaskStatus.Assigned);
            AssignedTasks.Add(task);
        }

        public void AcceptTask(Task task)
        {
            if (!AssignedTasks.Contains(task))
                throw new InvalidOperationException("User has not been assigned this task");

            task.ChangeTaskStatus(TaskStatus.Accepted);
        }

        public void DeclineTask(Task task)
        {
            if (!AssignedTasks.Contains(task))
                throw new InvalidOperationException("User has not been assigned this task");

            task.ChangeTaskStatus(TaskStatus.Declined);
            AssignedTasks.Remove(task);

        }

        public void CompleteTask(Task task)
        {
            task.ChangeTaskStatus(TaskStatus.Completed);
            AssignedTasks.Remove(task);
        }


        public override string ToString()
        {
            return $"ID: {id} Name: {name} Age:{age}";
        }
    }
}