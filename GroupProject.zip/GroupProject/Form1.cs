﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace TestingUsers
{
    public partial class Form1 : Form
    {
        TaskManager taskManager;
        UserManager userManager;


        public Form1()
        {
            InitializeComponent();
            taskManager = new TaskManager();
            userManager = new UserManager();
        }

        private void createUser_Click(object sender, EventArgs e)
        {
            User user = new User(textBox1.Text, Convert.ToInt16(textBox2.Text), Convert.ToInt16(textBox3.Text));
            userManager.AddUser(user);
            listOfUsersCombo.Items.Add(user);
        }

        private void Assign_Click(object sender, EventArgs e)
        {
            User user = (User)listOfUsersCombo.SelectedItem;
            Task task = (Task)listOfTasksCombo.SelectedItem;
            taskManager.AssignTask(user, task);
        }

        private void createTask_Click(object sender, EventArgs e)
        {
            DateTime startTime = startTimePicker.Value;
            DateTime endTime = endTimePicker.Value;
            Task task = new Task(textBox4.Text, startTime, endTime);
            listOfTasksCombo.Items.Add(task);
        }

        private void GetAllTasks_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var returned = taskManager.GetAllTasks();
            foreach (var item in returned)
            {
                listBox1.Items.Add(item);
            }
        }

        private void GetUser_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            User user = (User)listOfUsersCombo.SelectedItem;
            var returned = taskManager.GetUserTasks(user);
            foreach (var task in returned)
            {
                listBox1.Items.Add(task);
            }
        }

        private void Decline_Click(object sender, EventArgs e)
        {
            Task task = (Task)listOfTasksCombo.SelectedItem;
            User user = (User)listOfUsersCombo.SelectedItem;
            user.DeclineTask(task);
        }

        private void Accept_Click(object sender, EventArgs e)
        {
            Task task = (Task)listOfTasksCombo.SelectedItem;
            User user = (User)listOfUsersCombo.SelectedItem;
            user.AcceptTask(task);
        }

        private void saveToCsv_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Binary Files|*.bin";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;

                // Save userManager and taskManager directly
                using (FileStream stream = new FileStream(fileName + "_users.bin", FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, userManager);
                }

                using (FileStream stream = new FileStream(fileName + "_tasks.bin", FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, taskManager);
                }
            }
        }

        private void loadFromCSV_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Binary Files|*.bin";
            openFileDialog1.Title = "Select Users File";

            OpenFileDialog openFileDialog2 = new OpenFileDialog();
            openFileDialog2.Filter = "Binary Files|*.bin";
            openFileDialog2.Title = "Select Tasks File";

            if (openFileDialog1.ShowDialog() == DialogResult.OK && openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                string userFileName = openFileDialog1.FileName;
                string taskFileName = openFileDialog2.FileName;

                if (File.Exists(userFileName) && File.Exists(taskFileName))
                {
                    // Load userManager and taskManager directly
                    using (FileStream stream = new FileStream(userFileName, FileMode.Open))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        userManager = (UserManager)formatter.Deserialize(stream);
                    }

                    using (FileStream stream = new FileStream(taskFileName, FileMode.Open))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        taskManager = (TaskManager)formatter.Deserialize(stream);
                    }

                    // Update comboboxes here...
                    listOfUsersCombo.Items.Clear();
                    foreach (var user in userManager.GetAllUsers())
                    {
                        listOfUsersCombo.Items.Add(user);
                    }

                    listOfTasksCombo.Items.Clear();
                    foreach (var task in taskManager.GetAllTasks())
                    {
                        listOfTasksCombo.Items.Add(task);
                    }
                }
            }
        }

        private void listOfUsersCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            User user = (User)listOfUsersCombo.SelectedItem;
        }

        private void listOfTasksCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Task task = (Task)listOfTasksCombo.SelectedItem;
        }
    }
}