﻿using System;
using System.Collections.Generic;

namespace TestingUsers
{
    [Serializable]
    public class UserManager
    {
        private List<User> _listOfUsers;

        public UserManager()
        {
            _listOfUsers = new List<User>();
        }
        public void SetUsers(List<User> users)
        {
            this._listOfUsers = users;
        }


        public List<User> GetUserList()
        {
            return _listOfUsers;
        }
        public void AddUser(User user)
        {
            if (user == null) throw new ArgumentNullException("User is null");
            _listOfUsers.Add(user);
        }

        public List<User> GetAllUsers()
        {
            return _listOfUsers;
        }
    }
}