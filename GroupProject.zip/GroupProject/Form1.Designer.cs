﻿namespace TestingUsers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createUser = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.listOfUsersCombo = new System.Windows.Forms.ComboBox();
            this.createTask = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.GetAllTasks = new System.Windows.Forms.Button();
            this.listOfTasksCombo = new System.Windows.Forms.ComboBox();
            this.GetUserTasks = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.saveToCsv = new System.Windows.Forms.Button();
            this.loadFromCSV = new System.Windows.Forms.Button();
            this.startTimePicker = new System.Windows.Forms.DateTimePicker();
            this.endTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // createUser
            // 
            this.createUser.Location = new System.Drawing.Point(115, 241);
            this.createUser.Name = "createUser";
            this.createUser.Size = new System.Drawing.Size(179, 27);
            this.createUser.TabIndex = 0;
            this.createUser.Text = "Create user";
            this.createUser.UseVisualStyleBackColor = true;
            this.createUser.Click += new System.EventHandler(this.createUser_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(489, 411);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 33);
            this.button2.TabIndex = 1;
            this.button2.Text = "Assign Task";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Assign_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(137, 133);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(135, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(138, 174);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(135, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(137, 211);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(135, 20);
            this.textBox3.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(94, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 27);
            this.label1.TabIndex = 5;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(98, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 27);
            this.label2.TabIndex = 6;
            this.label2.Text = "age";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(102, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 27);
            this.label3.TabIndex = 7;
            this.label3.Text = "id";
            // 
            // listOfUsersCombo
            // 
            this.listOfUsersCombo.FormattingEnabled = true;
            this.listOfUsersCombo.Location = new System.Drawing.Point(523, 328);
            this.listOfUsersCombo.Name = "listOfUsersCombo";
            this.listOfUsersCombo.Size = new System.Drawing.Size(173, 21);
            this.listOfUsersCombo.TabIndex = 8;
            this.listOfUsersCombo.SelectedIndexChanged += new System.EventHandler(this.listOfUsersCombo_SelectedIndexChanged);
            // 
            // createTask
            // 
            this.createTask.Location = new System.Drawing.Point(619, 264);
            this.createTask.Name = "createTask";
            this.createTask.Size = new System.Drawing.Size(152, 31);
            this.createTask.TabIndex = 9;
            this.createTask.Text = "Create task";
            this.createTask.UseVisualStyleBackColor = true;
            this.createTask.Click += new System.EventHandler(this.createTask_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(619, 122);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(135, 20);
            this.textBox4.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(514, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 27);
            this.label4.TabIndex = 13;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(514, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 27);
            this.label5.TabIndex = 14;
            this.label5.Text = "startTime";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(514, 211);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 27);
            this.label6.TabIndex = 15;
            this.label6.Text = "End time";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(0, 310);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(481, 134);
            this.listBox1.TabIndex = 16;
            // 
            // GetAllTasks
            // 
            this.GetAllTasks.Location = new System.Drawing.Point(402, 284);
            this.GetAllTasks.Name = "GetAllTasks";
            this.GetAllTasks.Size = new System.Drawing.Size(79, 20);
            this.GetAllTasks.TabIndex = 17;
            this.GetAllTasks.Text = "Get All tasks";
            this.GetAllTasks.UseVisualStyleBackColor = true;
            this.GetAllTasks.Click += new System.EventHandler(this.GetAllTasks_Click);
            // 
            // listOfTasksCombo
            // 
            this.listOfTasksCombo.FormattingEnabled = true;
            this.listOfTasksCombo.Location = new System.Drawing.Point(523, 355);
            this.listOfTasksCombo.Name = "listOfTasksCombo";
            this.listOfTasksCombo.Size = new System.Drawing.Size(173, 21);
            this.listOfTasksCombo.TabIndex = 18;
            this.listOfTasksCombo.SelectedIndexChanged += new System.EventHandler(this.listOfTasksCombo_SelectedIndexChanged);
            // 
            // GetUserTasks
            // 
            this.GetUserTasks.Location = new System.Drawing.Point(301, 284);
            this.GetUserTasks.Name = "GetUserTasks";
            this.GetUserTasks.Size = new System.Drawing.Size(95, 20);
            this.GetUserTasks.TabIndex = 19;
            this.GetUserTasks.Text = "Get User Tasks";
            this.GetUserTasks.UseVisualStyleBackColor = true;
            this.GetUserTasks.Click += new System.EventHandler(this.GetUser_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(581, 410);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 33);
            this.button4.TabIndex = 20;
            this.button4.Text = "Decline Task";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Decline_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(675, 410);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(79, 33);
            this.button5.TabIndex = 21;
            this.button5.Text = "Accept Task";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Accept_Click);
            // 
            // saveToCsv
            // 
            this.saveToCsv.Location = new System.Drawing.Point(258, 31);
            this.saveToCsv.Name = "saveToCsv";
            this.saveToCsv.Size = new System.Drawing.Size(101, 27);
            this.saveToCsv.TabIndex = 22;
            this.saveToCsv.Text = "Save";
            this.saveToCsv.UseVisualStyleBackColor = true;
            this.saveToCsv.Click += new System.EventHandler(this.saveToCsv_Click);
            // 
            // loadFromCSV
            // 
            this.loadFromCSV.Location = new System.Drawing.Point(380, 31);
            this.loadFromCSV.Name = "loadFromCSV";
            this.loadFromCSV.Size = new System.Drawing.Size(101, 27);
            this.loadFromCSV.TabIndex = 23;
            this.loadFromCSV.Text = "Load";
            this.loadFromCSV.UseVisualStyleBackColor = true;
            this.loadFromCSV.Click += new System.EventHandler(this.loadFromCSV_Click);
            // 
            // startTimePicker
            // 
            this.startTimePicker.Location = new System.Drawing.Point(609, 160);
            this.startTimePicker.Name = "startTimePicker";
            this.startTimePicker.Size = new System.Drawing.Size(168, 20);
            this.startTimePicker.TabIndex = 24;
            // 
            // endTimePicker
            // 
            this.endTimePicker.Location = new System.Drawing.Point(609, 211);
            this.endTimePicker.Name = "endTimePicker";
            this.endTimePicker.Size = new System.Drawing.Size(168, 20);
            this.endTimePicker.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.endTimePicker);
            this.Controls.Add(this.startTimePicker);
            this.Controls.Add(this.loadFromCSV);
            this.Controls.Add(this.saveToCsv);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.GetUserTasks);
            this.Controls.Add(this.listOfTasksCombo);
            this.Controls.Add(this.GetAllTasks);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.createTask);
            this.Controls.Add(this.listOfUsersCombo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.createUser);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DateTimePicker startTimePicker;
        private System.Windows.Forms.DateTimePicker endTimePicker;

        private System.Windows.Forms.Button saveToCsv;
        private System.Windows.Forms.Button loadFromCSV;

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;

        private System.Windows.Forms.Button GetUserTasks;

        private System.Windows.Forms.ComboBox listOfTasksCombo;

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button GetAllTasks;

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button createUser;
        private System.Windows.Forms.ComboBox listOfUsersCombo;
        private System.Windows.Forms.TextBox textBox4;

        private System.Windows.Forms.Button createTask;
        private System.Windows.Forms.Button button2;

        #endregion
    }
}